package com.cg.mobilebilling.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.services.BillingServices;

@Controller
public class MobileBillingController {
	@Autowired
private BillingServices billingServices;
	Customer customer;
	@RequestMapping("/registerCustomer")
	public ModelAndView registerAssociateAction(@Valid@ModelAttribute Customer customer,BindingResult bindingResult) throws BillingServicesDownException {
		if(bindingResult.hasErrors())
			return new ModelAndView("registerPage");
		customer=billingServices.acceptCustomerDetails(customer);
		return new ModelAndView("registrationSuccessPage", "customer", customer);
}
	@ModelAttribute
	public Customer getCustomer() {
		Customer customer=new Customer();
		return customer;
}
}
