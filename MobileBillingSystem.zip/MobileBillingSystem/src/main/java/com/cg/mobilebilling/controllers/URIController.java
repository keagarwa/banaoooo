package com.cg.mobilebilling.controllers;

import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.mobilebilling.beans.Customer;

public class URIController {
Customer customer;
@RequestMapping(value= "/")
public String getIndexPage() {
	return "indexPage";
}
@RequestMapping("/register")
public String getRegisterPage() {
	return "registerPage";
}
@RequestMapping("/viewCustomerIndexPage")
public String getCustomerIndexPage() {
	return "customerIndexPage";
}

}
